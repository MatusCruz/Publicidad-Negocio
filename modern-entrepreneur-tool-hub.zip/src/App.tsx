import { useState } from "react";

// ─── SVG Icons ───────────────────────────────────────────────────────────────
const Logo = () => (
  <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
    <rect width="36" height="36" rx="10" fill="url(#logoGrad)" />
    <path d="M10 14 L14 18 L10 22" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M16 22 L26 22" stroke="#FFA726" strokeWidth="2.5" strokeLinecap="round" />
    <path d="M16 18 L22 18" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.7" />
    <defs>
      <linearGradient id="logoGrad" x1="0" y1="0" x2="36" y2="36">
        <stop offset="0%" stopColor="#1E88E5" />
        <stop offset="100%" stopColor="#00897B" />
      </linearGradient>
    </defs>
  </svg>
);

const IconRocket = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 006.16-12.12A14.98 14.98 0 009.631 8.41m5.96 5.96a14.926 14.926 0 01-5.841 2.58m-.119-8.54a6 6 0 00-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 00-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 01-2.448-2.448 14.9 14.9 0 01.06-.312m-2.24 2.39a4.493 4.493 0 00-1.757 4.306 4.493 4.493 0 004.306-1.758M16.5 9a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" />
  </svg>
);
const IconChart = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
  </svg>
);
const IconVideo = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);
const IconHeart = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
  </svg>
);
const IconBolt = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
  </svg>
);
const IconCoin = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);
const IconCheck = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
);
const IconStar = () => (
  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
  </svg>
);
const IconArrow = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
  </svg>
);
const IconMenu = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
  </svg>
);
const IconX = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
);

// ─── Breakeven Chart (SVG) ────────────────────────────────────────────────────
const BreakevenChart = ({ units }: { units: number }) => {
  const maxUnits = 200;
  const fixedCost = 80;
  const varCost = 0.5;
  const price = 1.2;
  const bep = Math.round(fixedCost / (price - varCost));

  const toX = (u: number) => (u / maxUnits) * 240 + 30;
  const toY = (val: number) => 150 - (val / 180) * 130;

  const revenuePoints = [0, maxUnits].map(u => `${toX(u)},${toY(u * price)}`).join(" ");
  const costPoints = [0, maxUnits].map(u => `${toX(u)},${toY(fixedCost + u * varCost)}`).join(" ");

  const currentRevenue = units * price;
  const currentCost = fixedCost + units * varCost;
  const profit = currentRevenue - currentCost;

  return (
    <div className="mt-3">
      <svg viewBox="0 0 280 160" className="w-full rounded-lg bg-slate-50 border border-slate-100">
        {/* Grid */}
        {[0, 40, 80, 120].map(y => (
          <line key={y} x1="30" y1={20 + y} x2="270" y2={20 + y} stroke="#e2e8f0" strokeWidth="0.5" />
        ))}
        {/* BEP vertical line */}
        <line x1={toX(bep)} y1="20" x2={toX(bep)} y2="150" stroke="#FFA726" strokeWidth="1" strokeDasharray="4 2" />
        {/* Revenue line */}
        <polyline points={revenuePoints} fill="none" stroke="#1E88E5" strokeWidth="2.5" strokeLinecap="round" />
        {/* Cost line */}
        <polyline points={costPoints} fill="none" stroke="#00897B" strokeWidth="2.5" strokeLinecap="round" />
        {/* Current unit marker */}
        <circle cx={toX(units)} cy={toY(currentRevenue)} r="4" fill="#1E88E5" />
        <circle cx={toX(units)} cy={toY(currentCost)} r="4" fill="#00897B" />
        {/* Labels */}
        <text x="32" y="16" fontSize="7" fill="#64748b">Ingresos</text>
        <text x="32" y="140" fontSize="7" fill="#64748b">Costos</text>
        <text x={toX(bep) - 14} y="16" fontSize="7" fill="#FFA726" fontWeight="bold">BEP</text>
        {/* Axes */}
        <line x1="30" y1="150" x2="270" y2="150" stroke="#cbd5e1" strokeWidth="1" />
        <line x1="30" y1="20" x2="30" y2="150" stroke="#cbd5e1" strokeWidth="1" />
      </svg>
      <div className="flex justify-between items-center mt-2 text-xs text-slate-500">
        <span>Unidades: <strong className="text-blue-700">{units}</strong></span>
        <span>Punto de equilibrio: <strong className="text-orange-500">{bep} u.</strong></span>
        <span className={`font-bold ${profit >= 0 ? "text-green-600" : "text-red-500"}`}>
          {profit >= 0 ? "+" : ""}${profit.toFixed(0)} ganancia
        </span>
      </div>
    </div>
  );
};

// ─── Viability Simulator ──────────────────────────────────────────────────────
const ViabilitySimulator = () => {
  const [units, setUnits] = useState(80);
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5">
      <div className="flex items-center gap-2 mb-1">
        <span className="p-2 bg-blue-50 rounded-lg text-blue-600"><IconChart /></span>
        <div>
          <h3 className="font-bold text-slate-800 text-sm">Simulador de Viabilidad</h3>
          <p className="text-xs text-slate-400">Calcula tu punto de equilibrio</p>
        </div>
      </div>
      <BreakevenChart units={units} />
      <div className="mt-3">
        <label className="text-xs text-slate-500 font-medium">Unidades vendidas / mes</label>
        <input
          type="range" min={0} max={200} value={units}
          onChange={e => setUnits(Number(e.target.value))}
          className="w-full mt-1 accent-blue-600"
        />
      </div>
    </div>
  );
};

// ─── Canvas Modelo ────────────────────────────────────────────────────────────
const canvasItems = [
  { label: "Propuesta de Valor", color: "bg-blue-50 border-blue-200", text: "¿Qué problema resuelves?" },
  { label: "Segmento Clientes", color: "bg-green-50 border-green-200", text: "¿A quién va dirigido?" },
  { label: "Canales", color: "bg-orange-50 border-orange-200", text: "¿Cómo llegas a ellos?" },
  { label: "Fuentes de Ingreso", color: "bg-teal-50 border-teal-200", text: "¿Cómo ganas dinero?" },
  { label: "Recursos Clave", color: "bg-indigo-50 border-indigo-200", text: "¿Qué necesitas?" },
  { label: "Estructura de Costos", color: "bg-rose-50 border-rose-200", text: "¿Cuáles son tus gastos?" },
];

const ModelCanvas = () => {
  const [cells, setCells] = useState<Record<string, string>>({});
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 mt-4">
      <div className="flex items-center gap-2 mb-3">
        <span className="p-2 bg-green-50 rounded-lg text-green-600">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
        </span>
        <div>
          <h3 className="font-bold text-slate-800 text-sm">Modelo Canvas Editable</h3>
          <p className="text-xs text-slate-400">Diseña tu modelo de negocio</p>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {canvasItems.map(item => (
          <div key={item.label} className={`${item.color} border rounded-xl p-2`}>
            <p className="text-[10px] font-bold text-slate-600 mb-1">{item.label}</p>
            <textarea
              className="w-full text-xs bg-transparent resize-none outline-none text-slate-700 placeholder:text-slate-300 min-h-[40px]"
              placeholder={item.text}
              value={cells[item.label] || ""}
              onChange={e => setCells(prev => ({ ...prev, [item.label]: e.target.value }))}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Video Player ─────────────────────────────────────────────────────────────
const videos = [
  { title: "Cómo validar tu idea de negocio", dur: "12:34", category: "Validación" },
  { title: "Finanzas básicas para emprendedores", dur: "18:02", category: "Finanzas" },
  { title: "Marketing digital sin presupuesto", dur: "9:47", category: "Marketing" },
];
const VideoPlayer = () => {
  const [active, setActive] = useState(0);
  const [playing, setPlaying] = useState(false);
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 mt-4">
      <div className="flex items-center gap-2 mb-3">
        <span className="p-2 bg-orange-50 rounded-lg text-orange-500"><IconVideo /></span>
        <div>
          <h3 className="font-bold text-slate-800 text-sm">Guías en Vídeo</h3>
          <span className="inline-block text-[10px] font-bold bg-green-100 text-green-700 px-2 py-0.5 rounded-full">SIN COPYRIGHT</span>
        </div>
      </div>
      {/* Player */}
      <div
        className="relative w-full rounded-xl overflow-hidden bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center cursor-pointer group"
        style={{ aspectRatio: "16/9" }}
        onClick={() => setPlaying(!playing)}
      >
        <div className={`absolute inset-0 flex items-center justify-center transition-opacity ${playing ? "opacity-0 group-hover:opacity-100" : "opacity-100"}`}>
          <div className="w-14 h-14 rounded-full bg-white/20 backdrop-blur flex items-center justify-center shadow-lg hover:scale-110 transition-transform">
            {playing
              ? <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg>
              : <svg className="w-7 h-7 text-white ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
            }
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 p-3">
          <p className="text-white text-xs font-semibold">{videos[active].title}</p>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-white/70 text-[10px]">{videos[active].dur}</span>
            <span className="text-[10px] bg-orange-500/80 text-white px-1.5 py-0.5 rounded">{videos[active].category}</span>
          </div>
        </div>
      </div>
      {/* List */}
      <div className="mt-3 space-y-1.5">
        {videos.map((v, i) => (
          <button
            key={i}
            onClick={() => { setActive(i); setPlaying(false); }}
            className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-left transition-all ${i === active ? "bg-blue-50 border border-blue-100" : "hover:bg-slate-50"}`}
          >
            <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${i === active ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-400"}`}>
              <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
            </div>
            <div className="flex-1 min-w-0">
              <p className={`text-xs font-medium truncate ${i === active ? "text-blue-700" : "text-slate-700"}`}>{v.title}</p>
              <p className="text-[10px] text-slate-400">{v.dur} · {v.category}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

// ─── Interest Quiz ────────────────────────────────────────────────────────────
const quizCategories = [
  {
    key: "pasiones", label: "Tus Pasiones", icon: <IconHeart />, color: "text-rose-500 bg-rose-50",
    options: ["Cocina y gastronomía", "Tecnología", "Arte y diseño", "Deportes", "Educación", "Moda"],
  },
  {
    key: "habilidades", label: "Tus Habilidades", icon: <IconBolt />, color: "text-amber-500 bg-amber-50",
    options: ["Programación", "Ventas", "Comunicación", "Diseño gráfico", "Contabilidad", "Idiomas"],
  },
  {
    key: "recursos", label: "Tus Recursos", icon: <IconCoin />, color: "text-teal-500 bg-teal-50",
    options: ["< $500 USD", "$500-$2,000", "$2,000-$10,000", "Solo tiempo", "Red de contactos", "Espacio físico"],
  },
];

const InterestQuiz = () => {
  const [selected, setSelected] = useState<Record<string, string[]>>({});
  const toggle = (cat: string, opt: string) => {
    setSelected(prev => {
      const cur = prev[cat] || [];
      return cur.includes(opt)
        ? { ...prev, [cat]: cur.filter(x => x !== opt) }
        : { ...prev, [cat]: [...cur, opt] };
    });
  };
  const total = Object.values(selected).flat().length;
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-bold text-slate-800 text-sm">Cuestionario de Intereses</h3>
          <p className="text-xs text-slate-400">Selecciona lo que te identifica</p>
        </div>
        <span className={`text-xs font-bold px-2 py-1 rounded-full ${total > 0 ? "bg-green-100 text-green-700" : "bg-slate-100 text-slate-400"}`}>
          {total} seleccionados
        </span>
      </div>
      <div className="space-y-4">
        {quizCategories.map(cat => (
          <div key={cat.key}>
            <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-lg text-xs font-bold mb-2 ${cat.color}`}>
              {cat.icon} {cat.label}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {cat.options.map(opt => {
                const isSelected = (selected[cat.key] || []).includes(opt);
                return (
                  <button
                    key={opt}
                    onClick={() => toggle(cat.key, opt)}
                    className={`text-xs px-3 py-1.5 rounded-full border transition-all font-medium ${isSelected
                      ? "bg-blue-600 text-white border-blue-600 shadow-sm"
                      : "bg-white text-slate-600 border-slate-200 hover:border-blue-300 hover:text-blue-600"
                      }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      {total >= 3 && (
        <button className="mt-4 w-full bg-gradient-to-r from-blue-600 to-teal-600 text-white text-sm font-bold py-2.5 rounded-xl hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
          <IconRocket /> Encontrar mi idea ideal
        </button>
      )}
    </div>
  );
};

// ─── Ideas Explorer ───────────────────────────────────────────────────────────
const ideas = [
  { emoji: "☕", title: "Café Especialidad", tag: "Gastronomía", trend: "+34%" },
  { emoji: "💻", title: "Freelance Tech", tag: "Tecnología", trend: "+61%" },
  { emoji: "🎨", title: "Diseño Digital", tag: "Creatividad", trend: "+28%" },
  { emoji: "📦", title: "E-commerce Niche", tag: "Comercio", trend: "+47%" },
  { emoji: "🧘", title: "Bienestar & Salud", tag: "Wellness", trend: "+52%" },
  { emoji: "📚", title: "Tutorías Online", tag: "Educación", trend: "+39%" },
  { emoji: "🚗", title: "Movilidad Urbana", tag: "Servicios", trend: "+21%" },
  { emoji: "🌱", title: "Agro-negocio", tag: "Ecología", trend: "+18%" },
];

const IdeasExplorer = () => {
  const [hovered, setHovered] = useState<number | null>(null);
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 mt-4">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="font-bold text-slate-800 text-sm">Explorador de Ideas</h3>
          <p className="text-xs text-slate-400">Negocios con mayor demanda 2025</p>
        </div>
        <span className="text-[10px] bg-orange-100 text-orange-600 font-bold px-2 py-0.5 rounded-full">EN TENDENCIA</span>
      </div>
      <div className="grid grid-cols-4 gap-2">
        {ideas.map((idea, i) => (
          <button
            key={i}
            onMouseEnter={() => setHovered(i)}
            onMouseLeave={() => setHovered(null)}
            className={`relative flex flex-col items-center p-3 rounded-xl border text-center transition-all duration-200 ${hovered === i
              ? "border-blue-300 bg-blue-50 shadow-md scale-105"
              : "border-slate-100 bg-slate-50 hover:border-blue-200"
              }`}
          >
            <span className="text-2xl mb-1">{idea.emoji}</span>
            <p className="text-[10px] font-bold text-slate-700 leading-tight">{idea.title}</p>
            <span className="mt-1 text-[9px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded-full font-bold">{idea.trend}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

// ─── Success Cases ────────────────────────────────────────────────────────────
const cases = [
  {
    name: "María González",
    business: "Pastelería Artesanal",
    location: "Bogotá, Colombia",
    photo: "https://images.pexels.com/photos/7752818/pexels-photo-7752818.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    revenue: "$4,200/mes",
    growth: "+180%",
    time: "8 meses",
    quote: "Con el Simulador de Viabilidad pude saber exactamente cuántos pasteles necesitaba vender para cubrir costos.",
    rating: 5,
  },
  {
    name: "Carlos Méndez",
    business: "Consultoría Digital",
    location: "CDMX, México",
    photo: "https://images.pexels.com/photos/11579595/pexels-photo-11579595.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    revenue: "$8,500/mes",
    growth: "+320%",
    time: "14 meses",
    quote: "El Canvas me ayudó a estructurar mi propuesta de valor y conseguir mis primeros clientes corporativos.",
    rating: 5,
  },
  {
    name: "Ana Reyes",
    business: "Tienda Online Moda",
    location: "Lima, Perú",
    photo: "https://images.pexels.com/photos/7413910/pexels-photo-7413910.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    revenue: "$3,100/mes",
    growth: "+95%",
    time: "5 meses",
    quote: "Las guías de vídeo me enseñaron marketing sin gastar un centavo. Ahora tengo 12,000 seguidores.",
    rating: 5,
  },
];

const SuccessCases = () => (
  <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5">
    <div className="flex items-center gap-2 mb-4">
      <span className="text-xl">🏆</span>
      <div>
        <h3 className="font-bold text-slate-800 text-sm">Negocios Reales</h3>
        <p className="text-xs text-slate-400">Emprendedores que lo lograron</p>
      </div>
    </div>
    <div className="space-y-4">
      {cases.map((c, i) => (
        <div key={i} className="border border-slate-100 rounded-xl overflow-hidden hover:shadow-md transition-shadow">
          <div className="h-24 overflow-hidden relative">
            <img src={c.photo} alt={c.name} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-2 left-3 right-3 flex items-end justify-between">
              <div>
                <p className="text-white font-bold text-sm">{c.name}</p>
                <p className="text-white/80 text-[10px]">{c.business} · {c.location}</p>
              </div>
              <div className="flex">
                {Array.from({ length: c.rating }).map((_, j) => (
                  <span key={j} className="text-yellow-400 text-xs"><IconStar /></span>
                ))}
              </div>
            </div>
          </div>
          <div className="p-3">
            <div className="grid grid-cols-3 gap-2 mb-3">
              <div className="text-center">
                <p className="text-xs font-bold text-blue-600">{c.revenue}</p>
                <p className="text-[10px] text-slate-400">Ingresos</p>
              </div>
              <div className="text-center border-x border-slate-100">
                <p className="text-xs font-bold text-green-600">{c.growth}</p>
                <p className="text-[10px] text-slate-400">Crecimiento</p>
              </div>
              <div className="text-center">
                <p className="text-xs font-bold text-orange-500">{c.time}</p>
                <p className="text-[10px] text-slate-400">Tiempo</p>
              </div>
            </div>
            <p className="text-[11px] text-slate-500 italic leading-relaxed">"{c.quote}"</p>
          </div>
        </div>
      ))}
    </div>
  </div>
);

// ─── Next Steps Checklist ─────────────────────────────────────────────────────
const steps = [
  { done: true, text: "Definir tu propuesta de valor única" },
  { done: true, text: "Completar tu Modelo Canvas" },
  { done: false, text: "Calcular punto de equilibrio en el simulador" },
  { done: false, text: "Ver guía: Valida tu idea en 7 días" },
  { done: false, text: "Registrar tu primera venta de prueba" },
  { done: false, text: "Crear perfil en redes sociales" },
  { done: false, text: "Abrir cuenta bancaria de negocios" },
];

const NextSteps = () => {
  const [done, setDone] = useState<boolean[]>(steps.map(s => s.done));
  const completed = done.filter(Boolean).length;
  const pct = Math.round((completed / steps.length) * 100);
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 mt-4">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="font-bold text-slate-800 text-sm">Próximos Pasos</h3>
          <p className="text-xs text-slate-400">Tu hoja de ruta al éxito</p>
        </div>
        <div className="text-right">
          <p className="text-lg font-bold text-blue-600">{pct}%</p>
          <p className="text-[10px] text-slate-400">completado</p>
        </div>
      </div>
      {/* Progress bar */}
      <div className="w-full bg-slate-100 rounded-full h-2 mb-4">
        <div
          className="bg-gradient-to-r from-blue-500 to-teal-500 h-2 rounded-full transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="space-y-2">
        {steps.map((step, i) => (
          <button
            key={i}
            onClick={() => setDone(prev => prev.map((v, j) => j === i ? !v : v))}
            className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-left transition-all ${done[i] ? "bg-green-50" : "hover:bg-slate-50"}`}
          >
            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${done[i] ? "border-green-500 bg-green-500 text-white" : "border-slate-200 text-transparent"}`}>
              <IconCheck />
            </div>
            <span className={`text-xs font-medium ${done[i] ? "text-green-700 line-through decoration-green-300" : "text-slate-700"}`}>
              {step.text}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};

// ─── Hero Banner ──────────────────────────────────────────────────────────────
const HeroBanner = () => (
  <section className="relative overflow-hidden bg-gradient-to-br from-blue-700 via-blue-600 to-teal-600 py-16 px-4">
    {/* Decorative circles */}
    <div className="absolute -top-16 -right-16 w-64 h-64 rounded-full bg-white/5" />
    <div className="absolute -bottom-24 -left-12 w-80 h-80 rounded-full bg-white/5" />
    <div className="absolute top-1/2 right-1/4 w-32 h-32 rounded-full bg-orange-400/10" />
    <div className="relative max-w-5xl mx-auto text-center">
      <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur text-white text-xs font-bold px-4 py-1.5 rounded-full mb-6">
        <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
        +12,000 emprendedores activos
      </div>
      <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white leading-tight mb-4">
        Transforma tu Idea<br />
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-300 to-yellow-200">
          en un Negocio Rentable
        </span>
      </h1>
      <p className="text-blue-100 text-base sm:text-lg max-w-2xl mx-auto mb-8">
        Herramientas inteligentes, guías paso a paso y simuladores financieros para llevar tu emprendimiento al siguiente nivel. Todo en un solo lugar.
      </p>
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
        <button className="group flex items-center gap-2 bg-orange-400 hover:bg-orange-500 text-white font-bold px-8 py-3.5 rounded-2xl shadow-lg shadow-orange-500/30 transition-all hover:scale-105">
          <IconRocket />
          Empieza Gratis Ahora
          <IconArrow />
        </button>
        <button className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white font-semibold px-6 py-3.5 rounded-2xl backdrop-blur transition-all border border-white/20">
          <IconVideo />
          Ver Demo
        </button>
      </div>
      {/* Stats */}
      <div className="mt-12 grid grid-cols-3 gap-4 max-w-lg mx-auto">
        {[
          { val: "95%", label: "Tasa de finalización" },
          { val: "2.3x", label: "Más ingresos promedio" },
          { val: "48h", label: "De idea a plan de negocio" },
        ].map((s, i) => (
          <div key={i} className="text-center">
            <p className="text-2xl font-extrabold text-white">{s.val}</p>
            <p className="text-blue-200 text-xs mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

// ─── Navbar ───────────────────────────────────────────────────────────────────
const navLinks = ["Inicio", "Simuladores", "Guías de Vídeo", "Ideas de Negocio", "Mi Cuenta"];

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("Inicio");
  return (
    <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur border-b border-slate-100 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 flex items-center justify-between h-16">
        {/* Logo */}
        <div className="flex items-center gap-2.5">
          <Logo />
          <div>
            <span className="font-extrabold text-slate-800 text-base leading-tight block">Calcula</span>
            <span className="font-extrabold text-blue-600 text-base leading-tight block -mt-1.5">y Lanza</span>
          </div>
        </div>
        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-1">
          {navLinks.map(link => (
            <button
              key={link}
              onClick={() => setActive(link)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${active === link
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-600 hover:bg-slate-100 hover:text-slate-800"
                }`}
            >
              {link}
            </button>
          ))}
        </div>
        {/* CTA Button */}
        <div className="hidden md:flex items-center gap-3">
          <button className="bg-gradient-to-r from-orange-400 to-orange-500 text-white text-sm font-bold px-5 py-2 rounded-xl hover:opacity-90 transition-opacity shadow-sm">
            Comenzar Gratis
          </button>
        </div>
        {/* Mobile Menu Toggle */}
        <button onClick={() => setOpen(!open)} className="md:hidden p-2 rounded-xl hover:bg-slate-100">
          {open ? <IconX /> : <IconMenu />}
        </button>
      </div>
      {/* Mobile Menu */}
      {open && (
        <div className="md:hidden border-t border-slate-100 bg-white px-4 py-3 space-y-1">
          {navLinks.map(link => (
            <button
              key={link}
              onClick={() => { setActive(link); setOpen(false); }}
              className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${active === link ? "bg-blue-50 text-blue-700" : "text-slate-600 hover:bg-slate-50"}`}
            >
              {link}
            </button>
          ))}
          <button className="w-full mt-2 bg-orange-400 text-white text-sm font-bold px-5 py-2.5 rounded-xl hover:bg-orange-500">
            Comenzar Gratis
          </button>
        </div>
      )}
    </nav>
  );
};

// ─── Footer ───────────────────────────────────────────────────────────────────
const Footer = () => (
  <footer className="bg-slate-900 text-slate-400 pt-12 pb-6 px-4 mt-16">
    <div className="max-w-6xl mx-auto">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
        {/* Brand */}
        <div className="col-span-2 md:col-span-1">
          <div className="flex items-center gap-2 mb-3">
            <Logo />
            <div>
              <span className="font-extrabold text-white text-sm block leading-tight">Calcula y Lanza</span>
              <span className="text-xs text-slate-400">Hub para Emprendedores</span>
            </div>
          </div>
          <p className="text-xs leading-relaxed text-slate-500">
            La plataforma todo-en-uno para emprendedores que quieren resultados reales, no solo sueños.
          </p>
        </div>
        {/* Links */}
        {[
          { title: "Herramientas", links: ["Simulador de Viabilidad", "Modelo Canvas", "Calculadora de Precios", "Proyección Financiera"] },
          { title: "Recursos", links: ["Guías de Vídeo", "Blog Emprendedor", "Casos de Éxito", "Comunidad"] },
          { title: "Empresa", links: ["Acerca de nosotros", "Contacto", "Política de Privacidad", "Términos de Uso"] },
        ].map(col => (
          <div key={col.title}>
            <h4 className="text-white font-bold text-sm mb-3">{col.title}</h4>
            <ul className="space-y-2">
              {col.links.map(l => (
                <li key={l}>
                  <a href="#" className="text-xs hover:text-teal-400 transition-colors">{l}</a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-slate-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
        <p className="text-xs text-slate-600">Calcula y Lanza · Todos los derechos reservados · 2025</p>
        <div className="flex items-center gap-3">
          {["Twitter", "LinkedIn", "YouTube", "Instagram"].map(s => (
            <a key={s} href="#" className="text-xs hover:text-teal-400 transition-colors">{s}</a>
          ))}
        </div>
      </div>
    </div>
  </footer>
);

// ─── Section Headings ─────────────────────────────────────────────────────────
const SectionHeader = ({ emoji, title, subtitle }: { emoji: string; title: string; subtitle: string }) => (
  <div className="mb-5">
    <div className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-50 to-teal-50 border border-blue-100 px-3 py-1.5 rounded-full mb-2">
      <span>{emoji}</span>
      <span className="text-xs font-bold text-blue-700">{title}</span>
    </div>
    <p className="text-slate-500 text-xs">{subtitle}</p>
  </div>
);

// ─── App Root ─────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Navbar />
      <HeroBanner />

      {/* Features strip */}
      <div className="bg-white border-b border-slate-100">
        <div className="max-w-6xl mx-auto px-4 py-4 flex flex-wrap justify-center gap-6">
          {[
            { icon: "⚡", text: "Simuladores en tiempo real" },
            { icon: "🎬", text: "Vídeos sin copyright" },
            { icon: "🗺️", text: "Canvas editable" },
            { icon: "💡", text: "Ideas de negocio IA" },
            { icon: "📈", text: "Análisis de viabilidad" },
          ].map(f => (
            <div key={f.text} className="flex items-center gap-2 text-slate-600 text-xs font-medium">
              <span>{f.icon}</span>{f.text}
            </div>
          ))}
        </div>
      </div>

      {/* Main 3-col grid */}
      <main className="max-w-6xl mx-auto px-4 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* ── Column 1: Herramientas Clave ── */}
          <div>
            <SectionHeader
              emoji="🛠️"
              title="Herramientas Clave"
              subtitle="Simuladores y plantillas para planificar tu negocio"
            />
            <ViabilitySimulator />
            <ModelCanvas />
            <VideoPlayer />
          </div>

          {/* ── Column 2: Encuentra Tu Idea ── */}
          <div>
            <SectionHeader
              emoji="💡"
              title="Encuentra Tu Idea"
              subtitle="Descubre el negocio perfecto para tu perfil"
            />
            <InterestQuiz />
            <IdeasExplorer />
          </div>

          {/* ── Column 3: Casos de Éxito ── */}
          <div>
            <SectionHeader
              emoji="🏆"
              title="Casos de Éxito y Recursos"
              subtitle="Aprende de emprendedores que ya lo lograron"
            />
            <SuccessCases />
            <NextSteps />
          </div>

        </div>
      </main>

      {/* CTA Banner */}
      <section className="bg-gradient-to-r from-orange-400 to-orange-500 py-12 px-4 text-center">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-3">
          ¿Listo para lanzar tu negocio?
        </h2>
        <p className="text-orange-100 text-sm mb-6 max-w-lg mx-auto">
          Únete a más de 12,000 emprendedores que ya están construyendo su futuro con Calcula y Lanza.
        </p>
        <button className="bg-white text-orange-500 font-extrabold px-8 py-3.5 rounded-2xl hover:scale-105 transition-transform shadow-lg flex items-center gap-2 mx-auto">
          <IconRocket /> Crear mi cuenta gratis
        </button>
      </section>

      <Footer />
    </div>
  );
}
